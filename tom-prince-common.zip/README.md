## Running locally
1. Install dependencies
2. yarn start

## Hypothetical Additions Given More Time

1. Actually finish
2. Fix validation
3. Transitions
4. Better Error handling
5. Correcting information from the confirmation screen

